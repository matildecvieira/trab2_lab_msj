# extractor.py
# Tarefa 1 - Extracao de Texto Multi-formato
# Suporta PDF, DOCX e TXT

import fitz          # PyMuPDF
import docx


def extrair_pdf(caminho):
    """Le um ficheiro PDF e devolve o texto bruto, pagina a pagina."""
    documento = fitz.open(caminho)
    texto_total = ""
    for numero, pagina in enumerate(documento):
        texto_pagina = pagina.get_text("text")
        texto_total += f"[PAGINA {numero + 1}]\n"
        texto_total += texto_pagina
        texto_total += "\n"
    documento.close()
    return texto_total


def extrair_docx(caminho):
    """Le um ficheiro DOCX e devolve o texto bruto preservando paragrafos."""
    doc = docx.Document(caminho)
    linhas = []
    for paragrafo in doc.paragraphs:
        linhas.append(paragrafo.text)
    return "\n".join(linhas)


def extrair_txt(caminho):
    """Le um ficheiro TXT tentando varios encodings para nao perder caracteres."""
    encodings = ["utf-8", "latin-1", "cp1252"]
    for enc in encodings:
        try:
            with open(caminho, "r", encoding=enc) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    # se nenhum funcionar, le em modo binario e substitui erros
    with open(caminho, "rb") as f:
        return f.read().decode("utf-8", errors="replace")


def extrair_texto(caminho, extensao):
    """Funcao principal - escolhe o metodo certo consoante a extensao."""
    extensao = extensao.lower()
    if extensao == "pdf":
        return extrair_pdf(caminho)
    elif extensao == "docx":
        return extrair_docx(caminho)
    elif extensao == "txt":
        return extrair_txt(caminho)
    else:
        raise ValueError(f"Formato nao suportado: {extensao}")
