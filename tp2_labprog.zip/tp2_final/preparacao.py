# preparacao.py
# Tarefa 3 - Preparacao do Input para Normalizacao

import re
from langdetect import detect, DetectorFactory

# garante resultados consistentes na detecao de idioma
DetectorFactory.seed = 0


# ── Detecao de idioma ──────────────────────────────────────────

NOMES_IDIOMA = {
    "pt": "Portugues",
    "en": "Ingles",
    "es": "Espanhol",
    "fr": "Frances",
    "de": "Alemao",
    "it": "Italiano",
}


def detetar_idioma(texto):
    """Deteta o idioma do texto. Devolve (codigo, nome)."""
    try:
        amostra = texto[:2000]
        codigo = detect(amostra)
        nome = NOMES_IDIOMA.get(codigo, codigo.upper())
        return codigo, nome
    except Exception:
        return "unknown", "Desconhecido"


# ── Segmentacao em chunks ──────────────────────────────────────

def dividir_em_chunks(texto, max_chars=1500, sobreposicao=100):
    """
    Divide o texto em blocos de tamanho maximo max_chars.
    Respeita paragrafos e frases para nao cortar a meio.
    """
    paragrafos = re.split(r"\n{2,}", texto)
    chunks = []
    atual = ""

    for para in paragrafos:
        para = para.strip()
        if not para:
            continue

        # paragrafo maior que o limite -> parte por frases
        if len(para) > max_chars:
            frases = re.split(r"(?<=[.!?])\s+", para)
            for frase in frases:
                if len(atual) + len(frase) + 1 > max_chars:
                    if atual:
                        chunks.append(atual.strip())
                    # sobreposicao para manter contexto
                    atual = atual[-sobreposicao:] + " " + frase if atual else frase
                else:
                    atual += (" " if atual else "") + frase
        else:
            if len(atual) + len(para) + 2 > max_chars:
                if atual:
                    chunks.append(atual.strip())
                atual = atual[-sobreposicao:] + "\n\n" + para if atual else para
            else:
                atual += ("\n\n" if atual else "") + para

    if atual.strip():
        chunks.append(atual.strip())

    return chunks


# ── Geracao de prompts ─────────────────────────────────────────

TEMPLATES_PROMPT = {
    "pt": (
        "Normaliza o seguinte texto em Portugues, corrigindo erros "
        "ortograficos, gramaticais e de formatacao, mantendo o significado "
        "original. Devolve apenas o texto normalizado, sem comentarios:\n\n{chunk}"
    ),
    "en": (
        "Normalize the following English text by correcting spelling, "
        "grammar and formatting errors, preserving the original meaning. "
        "Return only the normalized text, no comments:\n\n{chunk}"
    ),
    "es": (
        "Normaliza el siguiente texto en Espanol, corrigiendo errores "
        "ortograficos, gramaticales y de formato, manteniendo el significado "
        "original. Devuelve solo el texto normalizado:\n\n{chunk}"
    ),
}

TEMPLATE_PADRAO = (
    "Normalize the following text, correcting errors and formatting issues, "
    "preserving the original meaning. Return only the normalized text:\n\n{chunk}"
)


def gerar_prompt(chunk, codigo_idioma):
    """Cria o prompt adequado ao idioma detetado."""
    template = TEMPLATES_PROMPT.get(codigo_idioma, TEMPLATE_PADRAO)
    return template.format(chunk=chunk)


# ── Funcao principal ───────────────────────────────────────────

def preparar_para_slm(texto, tamanho_chunk=1500):
    """
    Funcao principal da Tarefa 3.
    Devolve lista de dicionarios com chunk e prompt, mais info de idioma.
    """
    codigo_idioma, nome_idioma = detetar_idioma(texto)
    chunks = dividir_em_chunks(texto, max_chars=tamanho_chunk)

    resultado = []
    for i, chunk in enumerate(chunks):
        prompt = gerar_prompt(chunk, codigo_idioma)
        resultado.append({
            "numero": i + 1,
            "chunk": chunk,
            "prompt": prompt,
        })

    return resultado, codigo_idioma, nome_idioma
