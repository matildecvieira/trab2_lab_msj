# TP2 — Normalização de Texto com Pipeline de Pré-Processamento e SLMs
**Laboratório de Programação — 1º ano | UTAD**

## Como correr

```
pip install -r requirements.txt
python app.py
```
Abre o browser em **http://127.0.0.1:5000**

## Estrutura do projeto

```
tp2_labprog/
├── app.py           ← servidor Flask (liga os 3 módulos)
├── extractor.py     ← Tarefa 1: extração de texto (PDF, DOCX, TXT)
├── pipeline.py      ← Tarefa 2: pipeline de limpeza
├── preparacao.py    ← Tarefa 3: chunking, idioma e prompts
├── requirements.txt
├── templates/
│   └── index.html   ← interface web
└── uploads/         ← ficheiros carregados (criado automaticamente)
```

## Funcionalidades (Etapa 1)
- Extração de texto de PDF, DOCX e TXT preservando artefactos originais
- Pipeline de limpeza configurável com 5 etapas independentes
- Vista lado a lado antes/depois da limpeza
- Segmentação em chunks com tamanho ajustável
- Deteção automática de idioma
- Geração automática de prompts adequados ao idioma

## Grupo
- [Nome 1]
- [Nome 2]
- [Nome 3]
