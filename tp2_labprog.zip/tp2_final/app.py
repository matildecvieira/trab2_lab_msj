# app.py
# Aplicacao principal - junta os tres modulos e serve a interface web

from flask import Flask, render_template, request, jsonify
from werkzeug.utils import secure_filename
import os

from extractor import extrair_texto
from pipeline import correr_pipeline
from preparacao import preparar_para_slm

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB

FORMATOS_PERMITIDOS = {"pdf", "docx", "txt"}

os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)


def extensao(nome):
    return nome.rsplit(".", 1)[-1].lower() if "." in nome else ""


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        return jsonify({"erro": "Nenhum ficheiro enviado"}), 400

    f = request.files["file"]
    ext = extensao(f.filename)

    if ext not in FORMATOS_PERMITIDOS:
        return jsonify({"erro": "Formato nao suportado. Usa PDF, DOCX ou TXT."}), 400

    nome = secure_filename(f.filename)
    caminho = os.path.join(app.config["UPLOAD_FOLDER"], nome)
    f.save(caminho)

    texto = extrair_texto(caminho, ext)
    return jsonify({"texto_bruto": texto, "nome": nome, "chars": len(texto)})


@app.route("/limpar", methods=["POST"])
def limpar():
    dados = request.get_json()
    texto = dados.get("texto", "")
    opcoes = dados.get("opcoes", {})
    texto_limpo, etapas = correr_pipeline(texto, opcoes)
    return jsonify({"texto_limpo": texto_limpo, "etapas": etapas})


@app.route("/preparar", methods=["POST"])
def preparar():
    dados = request.get_json()
    texto = dados.get("texto", "")
    tamanho = int(dados.get("tamanho_chunk", 1500))
    chunks, codigo, nome_idioma = preparar_para_slm(texto, tamanho)
    return jsonify({
        "chunks": chunks,
        "idioma_codigo": codigo,
        "idioma_nome": nome_idioma,
        "total_chunks": len(chunks),
    })


if __name__ == "__main__":
    print("A iniciar a aplicacao...")
    print("Abre o browser em: http://127.0.0.1:5000")
    app.run(debug=True)
