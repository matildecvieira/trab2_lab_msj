# pipeline.py
# Tarefa 2 - Pipeline de Limpeza e Pre-Processamento

import re
import unicodedata


def remover_artefactos(texto):
    """Remove caracteres de controlo e normaliza unicode."""
    # remove caracteres de controlo (mantém \n e \t)
    texto = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", " ", texto)
    # normaliza unicode para forma NFC
    texto = unicodedata.normalize("NFC", texto)
    return texto


def remover_cabecalhos_rodapes(texto):
    """Deteta linhas repetidas entre paginas e remove-as."""
    paginas = re.split(r"\[PAGINA \d+\]", texto)

    if len(paginas) <= 2:
        return texto

    primeiras_linhas = []
    ultimas_linhas = []

    for pagina in paginas[1:]:
        linhas = [l.strip() for l in pagina.strip().split("\n") if l.strip()]
        if linhas:
            primeiras_linhas.append(linhas[0])
            ultimas_linhas.append(linhas[-1])

    n = len(paginas) - 1
    minimo = max(2, int(n * 0.7))

    repetidas_inicio = {l for l in set(primeiras_linhas) if primeiras_linhas.count(l) >= minimo}
    repetidas_fim    = {l for l in set(ultimas_linhas)   if ultimas_linhas.count(l)   >= minimo}

    resultado = []
    for i, pagina in enumerate(paginas):
        if i == 0:
            resultado.append(pagina)
            continue
        linhas = pagina.split("\n")
        filtradas = []
        for j, linha in enumerate(linhas):
            s = linha.strip()
            if s in repetidas_inicio and j <= 2:
                continue
            if s in repetidas_fim and j >= len(linhas) - 3:
                continue
            filtradas.append(linha)
        resultado.append("\n".join(filtradas))

    return "\n".join(resultado)


def remover_quebras_incorretas(texto):
    """Remove quebras de linha que estao no meio de uma frase."""
    # hifenizacao no fim da linha: "pala-\nvra" -> "palavra"
    texto = re.sub(r"-\n(?=[a-záéíóúâêôãõàüç])", "", texto, flags=re.IGNORECASE)
    # quebra dentro de frase (linha nao termina com pontuacao final)
    texto = re.sub(r"(?<![.!?:])\n(?=[a-záéíóúâêôãõàüç\[\(])", " ", texto, flags=re.IGNORECASE)
    return texto


def reconstruir_paragrafos(texto):
    """Agrupa linhas partidas e separa paragrafos com linha dupla."""
    texto = re.sub(r"\n{3,}", "\n\n", texto)
    return texto


def normalizar_espacos(texto):
    """Normaliza espacos multiplos, aspas e outros caracteres especiais."""
    texto = re.sub(r"[ \t]+", " ", texto)
    texto = re.sub(r" +\n", "\n", texto)
    texto = re.sub(r"\n +", "\n", texto)
    # aspas tipograficas -> neutras
    texto = texto.replace("\u201c", '"').replace("\u201d", '"')
    texto = texto.replace("\u2018", "'").replace("\u2019", "'")
    # travessao -> hifen duplo
    texto = texto.replace("\u2013", "--").replace("\u2014", "--")
    # reticencias
    texto = texto.replace("\u2026", "...")
    return texto


def correr_pipeline(texto, opcoes):
    """
    Corre as etapas da pipeline pela ordem correta.
    opcoes: dicionario com chaves booleanas para cada etapa.
    Devolve (texto_limpo, lista_de_etapas_aplicadas).
    """
    etapas_aplicadas = []

    if opcoes.get("remover_artefactos"):
        texto = remover_artefactos(texto)
        etapas_aplicadas.append("Remocao de artefactos")

    if opcoes.get("remover_cabecalhos_rodapes"):
        texto = remover_cabecalhos_rodapes(texto)
        etapas_aplicadas.append("Remocao de cabecalhos e rodapes")

    if opcoes.get("remover_quebras_incorretas"):
        texto = remover_quebras_incorretas(texto)
        etapas_aplicadas.append("Remocao de quebras de linha incorretas")

    if opcoes.get("reconstruir_paragrafos"):
        texto = reconstruir_paragrafos(texto)
        etapas_aplicadas.append("Reconstrucao de paragrafos")

    if opcoes.get("normalizar_espacos"):
        texto = normalizar_espacos(texto)
        etapas_aplicadas.append("Normalizacao de espacos e pontuacao")

    return texto, etapas_aplicadas
